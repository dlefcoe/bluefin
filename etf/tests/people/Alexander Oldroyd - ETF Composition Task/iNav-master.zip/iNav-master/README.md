# iNAV Dashboard

Required packages are in `requirements.txt`

To run in command line on mac:
``` zsh
> export FLASK_APP=iNav.py
> flask run

```

